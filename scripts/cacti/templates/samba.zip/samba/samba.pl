#!/usr/bin/perl -w

# Written by Dirk Dietrich (dirk@ruebenrotze.de) 05.2005
# Update by Felipe rayel (rayel@pocos-net.com.br) 08.2005
# Collecting Samba Stats
# Tested on FC3 Samba v3.0.10
# Tested on Debian Samba v3.0.14

#!/usr/bin/perl -w

if ($ARGV[0] eq "Files") {
        $n = `smbstatus -L|wc -l`;
        $n = $n -2;
} elsif ($ARGV[0] eq "Processes") {
        $n = `smbstatus -p|wc -l`;
        $n = $n - 4;
} elsif ($ARGV[0] eq "Shares") {
        $n = `smbstatus -S |wc -l`;
        $n = $n - 4;
}
chomp ($n);

print "$n";

