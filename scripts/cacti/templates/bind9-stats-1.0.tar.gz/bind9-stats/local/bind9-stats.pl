#!/usr/bin/perl

#
# Script to parse bind9 stats file for cacti
#
# Created By: Cory Powers <cory@uversaconsulting.net>
#

$STAT_FILE = "/var/cache/bind/named.stats";

process_stats();

$mode = lc(shift(@ARGV));
if($mode =~ /^query$/){
	$req_stat = lc(shift(@ARGV));
	dumpstats($req_stat);
}elsif($mode =~ /^index$/){
	dumpindexes();
}elsif($mode =~ /^snmpd$/){
	dumpsnmpdata();
}elsif($mode =~ /^get$/){
	$req_stat = lc(shift(@ARGV));
	$req_zone = join(" ", @ARGV);
	$req_zone = prepareindex($req_zone);
	getstat($req_zone, $req_stat);
}elsif($mode =~ /^getall$/){
	$req_zone = join(" ", @ARGV);
	$req_zone = prepareindex($req_zone);
	getallstats($req_zone);
}elsif($mode =~ /^dump$/){
	dumpdata();
}else{
	print_usage();
	exit(2);
}

exit(0);

sub print_usage{
	print("
Ways to use bind9-stats.pl:
bind9-stats.pl index
  Retreive list of all indexes
bind9-stats.pl query (zone|recursion|success|failure|nxrrset|referral|nxdomain)
  Get specified statistic for all indexes
bind9-stats.pl get (recursion|success|failure|nxrrset|referral|nxdomain) INDEX
 Get specified statistic for index INDEX
bind9-stats.pl getall INDEX
 Get all statistics for index INDEX

");
}

sub process_stats{
	# Die unless we can locate the stats file
	if (!open(STATS,$STAT_FILE)) {
			die "Failed to open $STAT_FILE: $!\n";
	}


	while(<STATS>){
		next if /^[\-\+]/; 
		next if /^\s*$/;
		if (/^([^\s]+) (\d+)\s*$/) {
			$stats_global{$1} = $2;
		}
		if (/^([^\s]+) (\d+) (.*)$/) {
			$zone = prepareindex($3);
			$stats_zone{$zone}{$1} = $2;
		}
	}
	close(STATS);
}

sub prepareindex{
	$input = shift @_;

	for ($input) {
		s/^\s+//;
		s/\s+$//;
		s/\s/_/;
	}
	return $input
}

sub dumpsnmpdata{
	foreach $stat (keys(%stats_global)) {
		print "GLOBAL.$stat = $stats_global{$stat}\n";
	}

	print("\nNumber of zones: ".keys(%stats_zone)."\n\n");
	foreach $zone (keys(%stats_zone)) {
		foreach $stat (keys(%{$stats_zone{$zone}})) {
			print("$zone.$stat=".$stats_zone{$zone}{$stat}."\n");
		}
	}
}

sub dumpdata{
	print("Global Stat Count: ".keys(%stats_global)."\n");

	foreach $stat (keys(%stats_global)) {
		print "$stat = $stats_global{$stat}\n";
	}

	print("\nNumber of zones: ".keys(%stats_zone)."\n\n");
	foreach $zone (keys(%stats_zone)) {
		print("Zone: ".$zone."\n");
		foreach $stat (keys(%{$stats_zone{$zone}})) {
			print("$stat:".$stats_zone{$zone}{$stat}."\n");
		}
	}
}

sub dumpindexes{
	print("GLOBAL\n");

	foreach $zone (keys(%stats_zone)) {
		print("$zone\n");
	}
}

sub dumpstats{
	$req_stat = shift(@_);

	if($req_stat =~ /zone/){
		print("GLOBAL:GLOBAL\n");
		foreach $zone (keys(%stats_zone)) {
			print("$zone:$zone\n");
		}
	}else{

		print("GLOBAL:".$stats_global{$req_stat}."\n");

		foreach $zone (keys(%stats_zone)) {
			print("$zone:".$stats_zone{$zone}{$req_stat}."\n");
		}
	}
}

sub getstat{
	$req_zone = shift(@_);
	$req_stat = shift(@_);

	if($req_zone =~ /GLOBAL/){
		print($stats_global{$req_stat});
	}else{
		print($stats_zone{$req_zone}{$req_stat});
	}
}

sub getallstats{
	$req_zone = shift(@_);

	if($req_zone =~ /GLOBAL/){
		foreach $stat (keys(%stats_global)) {
			print "$stat:$stats_global{$stat} ";
		}
	}else{
		foreach $stat (keys(%{$stats_zone{$req_zone}})) {
			print("$stat:".$stats_zone{$req_zone}{$stat}." ");
		}
	}
}
