#!/bin/bash

#
# Script to generate bind9 stats file to be run from cron
#
# Created By: Cory Powers <cory@uversaconsulting.net>
#


#############
# CONFIGURATION - Begin
#
# named.stats file location, this should match the
# file name and path for the statistics-file directive
# in your named.conf file
STAT_FILE=/var/cache/bind/named.stats

# Location of rndc executable
RNDC=/usr/sbin/rndc

# CONFIGURATION - End
#############

rm $STAT_FILE
$RNDC stats
RNDC_RET=$?
if [ $RNDC_RET -ne 0 ]; then
	echo "Error running $RNDC:$RNDC_RET"
	exit $RNDC_RET
else
	exit 0
fi
