** MIB Protocol Statistics (RFC1213) **
Created by BSOD2600

-Notes-

These scripts get the various detailed protocol statistics for IP / TCP / UDP / SNMP.  Since it polls the standard RFC1213-MIB objects, these should work on any SNMP networked device. The graphs are formatted to show the data 'per 5 minutes'. I did this because the standard output just wasn't as meaningful / pretty.


-Installation-

1) Drop RFC1213.xm into your \cacti\resources\snmp_queries\ folder.
2) Import the data query templates from \templates
3) Add the RFC1213 Statistics Data Query to a device.
4) From the 'Create Graphs for this Host' screen, select the protocol types and click Create.


-Changelog-

2.1 - Fixed graph template data source selection issues (Fixed IP graph template. Re-created SNMP graph template).
2.0 - Rewrite of the scripts ditching the Script server for pure/fast SNMP Data Query. Delete the ss_protocol* scripts from your \cacti\scripts\ folder. Delete the various *protocol statistics Data Input Methods.  The Data templates remain the same, so you should be able to continue to use the 1.x graph/data sources post-upgrade.
1.3 - tiny error fixed with ss_protocol_ip.php (gandalf)
1.2 - update to fully support SNMPv3 (gandalf)
1.1 - Updated scripts to account for some values not returned for hosts (thanks lvm).
1.0 - Initial release.
